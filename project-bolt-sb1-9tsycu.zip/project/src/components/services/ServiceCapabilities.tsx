import React from 'react';
import { CheckCircle } from 'lucide-react';
import AnimatedSection from '../animations/AnimatedSection';

interface ServiceCapability {
  title: string;
  features: string[];
}

interface ServiceCapabilitiesProps {
  capabilities: ServiceCapability[];
}

const ServiceCapabilities: React.FC<ServiceCapabilitiesProps> = ({ capabilities }) => {
  return (
    <AnimatedSection delay={0.2}>
      <div className="bg-gray-800/50 rounded-lg p-8 mb-16 border border-gray-700">
        <h2 className="text-2xl font-bold text-white mb-6">Service Capabilities</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {capabilities.map((capability, index) => (
            <div key={index} className="border border-gray-700 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-white mb-4">{capability.title}</h3>
              <ul className="space-y-3">
                {capability.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-blue-400 mr-2 flex-shrink-0 mt-1" />
                    <span className="text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </AnimatedSection>
  );
};

export default ServiceCapabilities;