export const fadeInUpVariant = {
  hidden: {
    opacity: 0,
    y: 50,
  },
  visible: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      delay,
      ease: [0.17, 0.55, 0.55, 1],
      type: "spring",
      damping: 15,
      stiffness: 200,
    },
  }),
};