import { useInView } from 'react-intersection-observer';

interface UseAnimationInViewProps {
  threshold?: number;
  triggerOnce?: boolean;
}

export const useAnimationInView = ({
  threshold = 0.1,
  triggerOnce = true,
}: UseAnimationInViewProps = {}) => {
  return useInView({
    threshold,
    triggerOnce,
  });
};