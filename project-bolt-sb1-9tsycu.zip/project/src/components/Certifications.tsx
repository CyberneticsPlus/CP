import React from 'react';
import { Award, Shield, CheckCircle } from 'lucide-react';
import AnimatedSection from './animations/AnimatedSection';

const Certifications = () => {
  return (
    <section className="py-20 bg-gray-900/50">
      <AnimatedSection className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Professional Certifications
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Our team holds industry-leading certifications, ensuring the highest standards of cybersecurity expertise
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {certificationGroups.map((group, index) => (
            <AnimatedSection
              key={index}
              delay={0.1 * index}
              className="bg-gray-800/50 rounded-xl p-6 border border-gray-700"
            >
              <div className="flex items-center mb-6">
                <group.icon className="w-8 h-8 text-blue-400 mr-3" />
                <h3 className="text-xl font-semibold text-white">{group.title}</h3>
              </div>
              <ul className="space-y-4">
                {group.certifications.map((cert, idx) => (
                  <li key={idx} className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-blue-400 mr-3 flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-white font-medium">{cert.name}</p>
                      <p className="text-gray-400 text-sm">{cert.issuer}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </AnimatedSection>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center justify-center px-6 py-3 bg-blue-600/20 rounded-xl">
            <Award className="w-5 h-5 text-blue-400 mr-2" />
            <span className="text-gray-300">
              100+ Professional Certifications Across Our Team
            </span>
          </div>
        </div>
      </AnimatedSection>
    </section>
  );
};

const certificationGroups = [
  {
    icon: Shield,
    title: 'Security Certifications',
    certifications: [
      { name: 'CISSP', issuer: 'ISC²' },
      { name: 'CISM', issuer: 'ISACA' },
      { name: 'CompTIA Security+', issuer: 'CompTIA' },
      { name: 'CEH', issuer: 'EC-Council' }
    ]
  },
  {
    icon: Award,
    title: 'Cloud Security',
    certifications: [
      { name: 'AWS Security Specialty', issuer: 'Amazon Web Services' },
      { name: 'Azure Security Engineer', issuer: 'Microsoft' },
      { name: 'GCP Security Engineer', issuer: 'Google Cloud' },
      { name: 'CCSP', issuer: 'ISC²' }
    ]
  },
  {
    icon: Shield,
    title: 'Specialized Security',
    certifications: [
      { name: 'OSCP', issuer: 'Offensive Security' },
      { name: 'GIAC GPEN', issuer: 'SANS Institute' },
      { name: 'CISA', issuer: 'ISACA' },
      { name: 'CRISC', issuer: 'ISACA' }
    ]
  }
];

export default Certifications;