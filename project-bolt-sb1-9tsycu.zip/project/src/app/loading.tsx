import Loading from '@/components/Loading';

export default function LoadingPage() {
  return <Loading />;
}