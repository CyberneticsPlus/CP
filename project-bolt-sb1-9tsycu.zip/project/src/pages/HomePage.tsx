import React from 'react';
import Hero from '../components/Hero';
import Services from '../components/Services';
import SecurityApproach from '../components/SecurityApproach';
import Features from '../components/Features';
import CustomerReviews from '../components/CustomerReviews';
import Contact from '../components/Contact';

const HomePage = () => {
  return (
    <>
      <Hero />
      <Services />
      <SecurityApproach />
      <Features />
      <CustomerReviews />
      <Contact />
    </>
  );
};

export default HomePage;