import React from 'react';
import { Terminal, Shield, Search, FileCheck } from 'lucide-react';
import ServiceBanner from '../components/ServiceBanner';
import ServiceFeatures from '../components/services/ServiceFeatures';
import ServiceCapabilities from '../components/services/ServiceCapabilities';
import AnimatedSection from '../components/animations/AnimatedSection';
import { IMAGES } from '../constants/images';

const features = [
  {
    icon: Search,
    title: 'Vulnerability Assessment',
    description: 'Comprehensive security testing and vulnerability discovery.',
  },
  {
    icon: Terminal,
    title: 'Ethical Hacking',
    description: 'Professional security testing by certified ethical hackers.',
  },
  {
    icon: Shield,
    title: 'Security Analysis',
    description: 'In-depth analysis of security vulnerabilities and risks.',
  },
  {
    icon: FileCheck,
    title: 'Detailed Reporting',
    description: 'Comprehensive reports with actionable recommendations.',
  },
];

const capabilities = [
  {
    title: 'Testing Methodology',
    features: [
      'Web application testing',
      'Network penetration testing',
      'Mobile app security testing',
      'API security assessment',
    ],
  },
  {
    title: 'Security Assessment',
    features: [
      'Vulnerability identification',
      'Risk assessment',
      'Exploitation testing',
      'Security recommendations',
    ],
  },
];

const PenetrationTesting = () => {
  return (
    <div>
      <ServiceBanner
        title="Penetration Testing"
        description="Professional security testing to identify vulnerabilities before attackers do"
        image={IMAGES.services.pentesting}
        icon={<Terminal className="w-8 h-8 text-blue-400" />}
      />

      <div className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ServiceFeatures features={features} />
          <ServiceCapabilities capabilities={capabilities} />
          
          <AnimatedSection delay={0.3} className="text-center">
            <h2 className="text-2xl font-bold text-white mb-8">Ready to Test Your Security?</h2>
            <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors">
              Schedule a Test
            </button>
          </AnimatedSection>
        </div>
      </div>
    </div>
  );
};

export default PenetrationTesting;