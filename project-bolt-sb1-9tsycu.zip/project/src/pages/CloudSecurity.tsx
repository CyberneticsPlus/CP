import React from 'react';
import { Cloud, Lock, Shield, Database } from 'lucide-react';
import ServiceBanner from '../components/ServiceBanner';
import ServiceFeatures from '../components/services/ServiceFeatures';
import ServiceCapabilities from '../components/services/ServiceCapabilities';
import AnimatedSection from '../components/animations/AnimatedSection';
import { IMAGES } from '../constants/images';

const features = [
  {
    icon: Lock,
    title: 'Cloud Access Security',
    description: 'Secure access control and identity management for cloud resources.',
  },
  {
    icon: Shield,
    title: 'Data Protection',
    description: 'Advanced encryption and data security measures.',
  },
  {
    icon: Database,
    title: 'Infrastructure Security',
    description: 'Comprehensive cloud infrastructure protection.',
  },
  {
    icon: Cloud,
    title: 'Cloud Compliance',
    description: 'Ensure compliance with industry standards and regulations.',
  },
];

const capabilities = [
  {
    title: 'Cloud Security Features',
    features: [
      'Multi-cloud security management',
      'Cloud workload protection',
      'Container security',
      'Serverless security',
    ],
  },
  {
    title: 'Security Controls',
    features: [
      'Identity and access management',
      'Data encryption',
      'Network security',
      'Configuration management',
    ],
  },
];

const CloudSecurity = () => {
  return (
    <div>
      <ServiceBanner
        title="Cloud Security"
        description="Comprehensive cloud infrastructure protection for modern enterprises"
        image={IMAGES.services.cloud}
        icon={<Cloud className="w-8 h-8 text-blue-400" />}
      />

      <div className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ServiceFeatures features={features} />
          <ServiceCapabilities capabilities={capabilities} />
          
          <AnimatedSection delay={0.3} className="text-center">
            <h2 className="text-2xl font-bold text-white mb-8">Secure Your Cloud Infrastructure</h2>
            <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors">
              Get Started
            </button>
          </AnimatedSection>
        </div>
      </div>
    </div>
  );
};

export default CloudSecurity;