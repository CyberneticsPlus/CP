import React from 'react';
import { Shield, Users, Award, Globe, CheckCircle } from 'lucide-react';
import AnimatedSection from '../components/animations/AnimatedSection';
import { IMAGES } from '../constants/images';

const AboutUs = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative h-[60vh] min-h-[500px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-gray-900/90 to-gray-900/70 z-10"></div>
          <img
            src={IMAGES.about.team}
            alt="CyberNeticsPlus Team"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">About CyberNeticsPlus</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Leading the future of cybersecurity with innovative solutions and expert services
          </p>
        </div>
      </div>

      {/* Mission Section */}
      <AnimatedSection className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-6">Our Mission</h2>
              <p className="text-gray-300 text-lg mb-6">
                At CyberNeticsPlus, we're committed to protecting organizations from evolving cyber threats through innovative security solutions and expert services. Our mission is to create a safer digital world for businesses and their customers.
              </p>
              <div className="space-y-4">
                {missionPoints.map((point, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="w-6 h-6 text-blue-400 mr-3 flex-shrink-0 mt-1" />
                    <p className="text-gray-300">{point}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-xl"></div>
              <img
                src={IMAGES.hero.cybersecurity}
                alt="Cybersecurity Operations"
                className="rounded-xl relative z-10"
              />
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Stats Section */}
      <AnimatedSection className="py-20 bg-gray-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="w-8 h-8 text-blue-400 mx-auto mb-4" />
                <div className="text-4xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-gray-300">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </AnimatedSection>

      {/* Values Section */}
      <AnimatedSection className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-gray-800/50 p-6 rounded-xl border border-gray-700">
                <value.icon className="w-8 h-8 text-blue-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-3">{value.title}</h3>
                <p className="text-gray-300">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
};

const missionPoints = [
  'Delivering enterprise-grade security solutions',
  'Providing 24/7 threat monitoring and response',
  'Ensuring compliance with industry standards',
  'Offering expert consultation and support',
];

const stats = [
  { icon: Shield, value: '500+', label: 'Clients Protected' },
  { icon: Users, value: '50+', label: 'Security Experts' },
  { icon: Award, value: '15+', label: 'Years Experience' },
  { icon: Globe, value: '24/7', label: 'Monitoring' },
];

const values = [
  {
    icon: Shield,
    title: 'Excellence',
    description: 'We strive for excellence in every security solution we deliver, ensuring the highest standards of protection.',
  },
  {
    icon: Users,
    title: 'Collaboration',
    description: 'We work closely with our clients to understand their unique needs and deliver tailored security solutions.',
  },
  {
    icon: Award,
    title: 'Innovation',
    description: 'We continuously evolve our solutions to stay ahead of emerging cyber threats and technologies.',
  },
];

export default AboutUs;